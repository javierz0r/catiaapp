import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Data } from './search.service';
import { ListPage } from '../list/list';
import { ProfilePage } from '../profile/profile';
import { FavoritesPage } from '../favorites/favorites';

/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
//cosas del buscador
  searchTerm : any="";
  jsonData : any;
//terminan cosas del buscador

  constructor(public navCtrl: NavController, public navParams: NavParams, public data: Data) {
  }

//funciones que se cargan al cargar search pagina  
  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchPage');

    //esta carga la usa el buscador
    this.setFilteredItems();
    //esta carga la usa el buscador
  }
//funciones que se cargan al cargar search pagina 
//declaro funciones de los botones de abajo
Profile() {
  this.navCtrl.push(ProfilePage);
}


List() {
  this.navCtrl.push(ListPage);
}

Search() {
  this.navCtrl.push(SearchPage);
}

Favorites() {
  this.navCtrl.push(FavoritesPage);
}
//declaradas funciones de los botones de abajo
  


  setFilteredItems() {
 
        this.jsonData = this.data.filterItems(this.searchTerm);
 
    }


}
