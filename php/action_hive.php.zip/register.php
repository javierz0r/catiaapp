<?php




header('Access-Control-Allow-Origin: *' );
    header('Access-Control-Allow-Credentials: true' );
    header('Access-Control-Request-Method: *');
    header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE,     OPTIONS');
    header('Access-Control-Allow-Headers: *,x-requested-with,Content-Type');
    header('X-Frame-Options: DENY');

if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
 
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
 
        exit(0);
    }
 
  require "dbconnect.php";
  $insert = 0;
    $data = file_get_contents("php://input");
    if (isset($data)) {
        $request = json_decode($data);
		$username = $request->username;
		$password = $request->password;
		$mobile = $request->mobile;
		$emailadd = $request->email;
		$insert = 0;
$con->beginTransaction();

try{
    
 $sql = "INSERT INTO infousers (username, password, telephone, email, avatar)
VALUES ('$username', '$password', '$mobile', '$emailadd', 'blobavatars/user.jpg')";
$result = $con->prepare($sql);
$result->execute();


 //.....::::::este ya lo hace la funcion global: da xp y pts iniciales:::::.....   
//$sql = "INSERT INTO user_current_points (username, total_win_points, total_consumed_points, actionconsult)
//VALUES ('$username', '4', '0', 'Register')";
//$result = $con->prepare($sql);
//$result->execute();
// $lastresult = $con->lastinsert();
// var_dump($sql1);
// die;
//    $con->commit();
// comentada la respuesta para imprimirla abajo    $response= "Registration successfull";


//$sql = "INSERT INTO user_current_xp (username, total_win_xp, actionconsult)
//VALUES ('$username', '1','Register')";
//$result = $con->prepare($sql);
//$result->execute();
    $con->commit();
    $response= "Registration successfull";
    

}catch(PDOException $response){
    $con->rollback();
    
}



//autoinsertare experiencia por registrarse fuera de la global fuction

//autoinsertada


	
   
//     //user_current_points
// } else {
//   $response= "Error: " . $sql ."<br>" .$sql1."<br>" . $db->error;
// }
    
	echo json_encode($response);


    }//


 
?>
