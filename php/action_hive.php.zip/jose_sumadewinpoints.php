<?php

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit(0);

}

require_once ("DbLogin.php");

$data = file_get_contents("php://input");

if (isset($data)) {
    $request = json_decode($data,true);
    $username = $request['username'];
}
//where username no imprime nada, se usara where 111 para solo mostrar 
//el json  de ese usuario temporalemente

$sql = "SELECT SUM( total_win_points ) FROM user_current_points WHERE username='111'; ";

$result = mysqli_query($con, $sql);
$response = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($response, array("total_win_points_sumado" => $row[0], )
       
        //  foreach (as)
        //  {
             
        //  }
        

    );
     $total_win_points_sumado = $response['0']['total_win_points_sumado'];
}         

$sql = "SELECT SUM( total_consumed_points ) FROM user_current_points WHERE username='111'; ";

$result = mysqli_query($con, $sql);
$response = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($response, array("total_consumed_points_sumado" => $row[0], )
        
         
        
    );
}  





$total_consumed_points_sumado = $response['0']['total_consumed_points_sumado'];
  
$total = $total_win_points_sumado-$total_consumed_points_sumado;


                 var_dump($total_win_points_sumado, $total_consumed_points);
        die;



//sumatoria de perdidos.





//sumatoria fin.

echo json_encode(array("server_response" => $total));
echo json_encode(array("server_response" => $total_win_points_sumado));
echo json_encode(array("server_response" => $total_consumed_points_sumado));

?>


