<?php

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit(0);

}

require "DbLogin.php";

$dataenvio = file_get_contents("php://input");
// var_dump($fuctiondata);
// die;
//el nombre de la decoficicacion json que me traje
if (isset($dataenvio)) {
    $request = json_decode($dataenvio,true);
//decodificado...

//transformamos la decodificacion en sql-php
    $actionconsult = $request['actionconsult'];
    $username = $request['username'];
}
//Transformada...

//seleccionamos de la tabla fp_experience_or_points cuando actionconsult es igual al nombre de la funcion que tal vez pueda estar o no en la tabla.

$sql = "SELECT * FROM fp_experience_or_points WHERE actionconsult='$actionconsult';";


$result = mysqli_query($con, $sql);
$rewardresponse = array();
//seleccionado...

//armamos las columnas para esa linea en especifica (el nombre de la funcion)
// y definimos el nombre de las variables a reutilizar en el case del backend.
while ($row = mysqli_fetch_array($result)) {
//identificadores existen
    array_push($rewardresponse, array("id_petition" => $row[0],
//respondido.

//armamos datos de la consulta sql y las definimos para reutilizarla en el backend.
//redefinimos la variable actionconsult con la extraida de la db
        "actionconsult" => $row[actionconsult],
                "experience" => $row[experience],
                "points" => $row[points],
                 "gaintoday" => veremos
        )
    );
    
//ARMADA la matriz (1x4) con respecto a la fuction que dara xp, puntos o ninguno

foreach ($rewardresponse as $gaintoday ){

//::::....inician las condiciones de llenado...::::::

if ($gaintoday [experience] == 0 && $gaintoday[points] == 1) {
    $gaintoday ['gaintoday'] = "pts";  
} elseif( $gaintoday [experience] == 1 && $gaintoday[points] == 0) {
        $gaintoday ['gaintoday'] = "xp";      
} elseif( $gaintoday [experience] == 1 && $gaintoday[points] == 1) {
    $gaintoday ['gaintoday'] = "ambos"; 
}
else{
    $gaintoday ['gaintoday'] = "any";    
}
//:::::....finalizan las condiciones de llenado....:::::
 }


 //::::;;;:........inician las conficiones de quedare...,,,.:::::::::

if ($gaintoday ['gaintoday'] == pts)
{
    $sql = "SELECT * FROM fp_how_much_xp_pts WHERE actionconsult='$actionconsult';";
    $result = mysqli_query($con, $sql);
    $amountptsget = array();
    //consultamos cuanto dare
    while ($row = mysqli_fetch_array($result)) {
        array_push($amountptsget, array("id_how_much_xp_pts" => $row[0],
            "actionconsult" => $row[actionconsult],
                    "pts_to_get" => $row[pts_to_get],
            )
        );
    $cuantospts = $amountptsget['0']['pts_to_get'];
     }
    
}
elseif ($gaintoday ['gaintoday'] == xp)
{
    $sql = "SELECT * FROM fp_how_much_xp_pts WHERE actionconsult='$actionconsult';";
    $result = mysqli_query($con, $sql);
    $amountxpget = array();
    //consultamos cuanto dare
    while ($row = mysqli_fetch_array($result)) {
        array_push($amountxpget, array("id_how_much_xp_pts" => $row[0],
            "actionconsult" => $row[actionconsult],
                    "xp_to_get" => $row[xp_to_get],
            )
        );
    $cuantaxp = $amountxpget['0']['xp_to_get'];
     }
     
   
}
elseif ($gaintoday ['gaintoday'] == ambos)
{
//se deberan llenar las variables how_much para las ganancias dobles    
    $sqldoblea = "SELECT * FROM fp_how_much_xp_pts WHERE actionconsult='$actionconsult';";
    $resultdoblea = mysqli_query($con, $sqldoblea);
    $amountxpget = array();
    //consultamos cuanto dare
    while ($row = mysqli_fetch_array($resultdoblea)) {
        array_push($amountxpget, array("id_how_much_xp_pts" => $row[0],
            "actionconsult" => $row[actionconsult],
                    "xp_to_get" => $row[xp_to_get],
            )
        );
    $cuantaxp = $amountxpget['0']['xp_to_get'];
     }
     $sqldobleb = "SELECT * FROM fp_how_much_xp_pts WHERE actionconsult='$actionconsult';";
     $resultdobleb = mysqli_query($con, $sqldobleb);
     $amountptsget = array();
     //consultamos cuanto dare
     while ($row = mysqli_fetch_array($resultdobleb)) {
         array_push($amountptsget, array("id_how_much_xp_pts" => $row[0],
             "actionconsult" => $row[actionconsult],
                     "pts_to_get" => $row[pts_to_get],
             )
         );
     $cuantospts = $amountptsget['0']['pts_to_get'];
      }
//verificado 2 consult con dump y valores locales de consulta, aprobado.
}
// elseif($gaintoday ['gaintoday'] == any)
// {
//     $gaintoday ['gaintoday'] = "any";
// }


//::::;;;:.......terminan las conficiones de quedare...,,,.:::::::::

//-----------------------------------------------------------------

//:::::::::::......inician las condiciones de insert.........::::::::

//interta puntos
if ($gaintoday ['gaintoday'] == pts)
{


    $sql = "INSERT INTO user_current_points (username, total_win_points, actionconsult)
    VALUES ('$username', '$cuantospts', '$actionconsult')";
    if ($con->query($sql) === TRUE) {
        $agregado= "agregado puntos";
    } else {
       $agregado= "Error: " . $sql . "<br>" . $db->error;
    }

//se cargara el log de la pts
$sqllogpts = "INSERT INTO fp_fuction_log_pts (username, by_the_fuction, earned_points)
VALUES ('$username', '$actionconsult', '$cuantospts')";
if ($con->query($sqllogpts) === TRUE) {
    $log2= "agregado log";
} else {
   $log2= "Error: " . $sqllogpts . "<br>" . $db->error;
}    

}
//inserta xp
elseif ($gaintoday ['gaintoday'] == xp)
{



$sql = "INSERT INTO user_current_xp (username, total_win_xp, actionconsult)
VALUES ('$username', '$cuantaxp', '$actionconsult')";
if ($con->query($sql) === TRUE) {
    $agregado= "agregado puntos";
} else {
   $agregado= "Error: " . $sql . "<br>" . $db->error;
}

//se cargara el log de la experiencia
$sqllogxp = "INSERT INTO fp_fuction_log_xp (username, by_the_fuction, earned_xp)
VALUES ('$username', '$actionconsult', '$cuantaxp')";
if ($con->query($sqllogxp) === TRUE) {
    $log2= "agregado log";
} else {
   $log2= "Error: " . $sqllogxp . "<br>" . $db->error;
}

}
elseif ($gaintoday ['gaintoday'] == ambos)
{
//siempre me cae en la condicion del inser

$sqlinsertdoblea = "INSERT INTO user_current_xp (username, total_win_xp, actionconsult)
VALUES ('$username', '$cuantaxp', '$actionconsult')";
if ($con->query($sqlinsertdoblea) === TRUE) {
    $agregado1= "agregado puntos";
} else {
   $agregado1= "Error: " . $sqlinsertdoblea . "<br>" . $db->error;
}

$sqlinsertdobleb = "INSERT INTO user_current_points (username, total_win_points, actionconsult)
VALUES ('$username', '$cuantospts', '$actionconsult')";
if ($con->query($sqlinsertdobleb) === TRUE) {
    $agregado2= "agregado puntos";
} else {
   $agregado2= "Error: " . $sqlinsertdobleb . "<br>" . $db->error;
}

//se carga el log de los pts (ambos).
$sqllogpts = "INSERT INTO fp_fuction_log_pts (username, by_the_fuction, earned_points)
VALUES ('$username', '$actionconsult', '$cuantospts')";
if ($con->query($sqllogpts) === TRUE) {
    $log2= "agregado log";
} else {
   $log2= "Error: " . $sqllogpts . "<br>" . $db->error;
}    

//se carga el log de la xp  la experiencia (ambos).

$sqllogxp = "INSERT INTO fp_fuction_log_xp (username, by_the_fuction, earned_xp)
VALUES ('$username', '$actionconsult', '$cuantaxp')";
if ($con->query($sqllogxp) === TRUE) {
    $log3= "agregado log";
} else {
   $log3= "Error: " . $sqllogxp . "<br>" . $db->error;
}

}


//ninguno de los casos   
elseif($gaintoday ['gaintoday'] == any){

    $sqllogfuctionnotexist = "INSERT INTO fp_fuction_log_not_found (fuction_name, fuction_description)
    VALUES ('$actionconsult', '$actionconsult asigned to gain')";
    if ($con->query($sqllogfuctionnotexist) === TRUE) {
        $agregado3= "agregado puntos";
    } else {
       $agregado3= "Error: " . $sqllogfuctionnotexist . "<br>" . $db->error;
    }
}

//:::::::::::......inician las condiciones de insert.........::::::::




echo json_encode(array("server_response_hive" => $gaintoday ));
 }
//cierre php
?>


