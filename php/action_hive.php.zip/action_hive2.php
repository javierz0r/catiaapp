<?php




header('Access-Control-Allow-Origin: *' );
    header('Access-Control-Allow-Credentials: true' );
    header('Access-Control-Request-Method: *');
    header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE,     OPTIONS');
    header('Access-Control-Allow-Headers: *,x-requested-with,Content-Type');
    header('X-Frame-Options: DENY');

if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
 
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
 
        exit(0);
    }
 
  require "dbconnect.php";
  $insert = 0;
    $data = file_get_contents("php://input");
    if (isset($data)) {
        $request = json_decode($data);
		$username = $request->username;
		$textrevie = $request->textrevie;
		$total_stars = $request->total_stars;
		$promo_or_localdd = $request->promo_or_local;
		$insert = 0;


try{
    

    $sql = "SELECT * FROM fp_experience_or_points WHERE actionconsult='reviewpromo'";
    
    
    $result = mysqli_query($con, $sql);
    $rewardresponse = array();
    //seleccionado...

    
    
    //armamos las columnas para esa linea en especifica (el nombre de la funcion)
    // y definimos el nombre de las variables a reutilizar en el case del backend.
    while ($row = mysqli_fetch_array($result)) {
    //identificadores existen
        array_push($rewardresponse, array("id_petition" => $row[0],
    //respondido.
    
    //armamos datos de la consulta sql y las definimos para reutilizarla en el backend.
    //redefinimos la variable actionconsult con la extraida de la db
            "actionconsult" => $row[actionconsult],
    //redefinida...
    //redefinimos la variable experience con la extraida de la db
                    "experience" => $row[experience],
                    "points" => $row[points],
                     "gaintoday" => veremos
    //redefinida...                
    //redefinimos la variable actionconsult con la extraida de la db           
    //redefinida...                
            )
        );

        var_dump($rewardresponse);
        die;

     }
}catch(PDOException $response){
    $con->rollback();
    
}

	
   
//     //user_current_points
// } else {
//   $response= "Error: " . $sql ."<br>" .$sql1."<br>" . $db->error;
// }
    
	echo json_encode($response);


	}//

 
?>
