<?php




header('Access-Control-Allow-Origin: *' );
    header('Access-Control-Allow-Credentials: true' );
    header('Access-Control-Request-Method: *');
    header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE,     OPTIONS');
    header('Access-Control-Allow-Headers: *,x-requested-with,Content-Type');
    header('X-Frame-Options: DENY');

if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
 
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
 
        exit(0);
    }
 
  require "dbconnect.php";
  $insert = 0;
    $data = file_get_contents("php://input");
    if (isset($data)) {
        $request = json_decode($data);
		$username = $request->username;
		$textrevie = $request->textrevie;
        $total_stars = $request->total_stars;
        $promo_or_localdd = $request->promo_or_local;
        $enviamepromoidreview = $request->enviamepromoidreview;
		$insert = 0;
$con->beginTransaction();

try{
    
 $sql = "INSERT INTO reviews_user (username, textrevie, total_stars, promo_or_local, id_promo)
VALUES ('$username', '$textrevie', '$total_stars', '$promo_or_localdd', '$enviamepromoidreview')";
$result = $con->prepare($sql);
$result->execute();


//...::ya no se gana puntos por aqui sino por la funcion global::...    
//$sql = "INSERT INTO user_current_points (username, total_win_points, total_consumed_points)
//VALUES ('$username', '1','?')";
//$result = $con->prepare($sql);
//$result->execute();
// $lastresult = $con->lastinsert();
// var_dump($sql1);
// die;
    $con->commit();
    $response= "Review successfull";
}catch(PDOException $response){
    $con->rollback();
    
}

	
   
//     //user_current_points
// } else {
//   $response= "Error: " . $sql ."<br>" .$sql1."<br>" . $db->error;
// }
    
	echo json_encode($response);


	}//

 
?>
