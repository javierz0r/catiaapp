

<?php



//   define('HOST','localhost');

//   define('USER','cyrus_user');

//   define('PASS','H(NN+2DT]=d~');

//   define('DB', 'cyrus_app2');

//   $con = mysqli_connect(HOST,USER,PASS,DB);

$db = 'cyrus_app2'; 
$host = 'localhost'; 
$user = 'cyrus_user'; 
$pass = 'H(NN+2DT]=d~'; 
$con = new PDO("mysql:dbname=".$db.";host=".$host,$user, $pass); 
$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

   if (!$con){
      die("Error in connection" . mysqli_connect_error()) ;
  }





?>