<?php

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit(0);

}

require_once ("DbLogin.php");

$data = file_get_contents("php://input");

if (isset($data)) {
    $request = json_decode($data,true);
    $username = $request['username'];
}


//$sql = "SELECT SUM( total_win_points ) as total_win_by_user FROM user_current_points UNION SELECT SUM( total_consumed_points ) as total_consumed_by_user FROM user_current_points WHERE username='111'";
//"SELECT SUM( total_win_points ) as total_win_by_user FROM user_current_points UNION SELECT SUM( total_consumed_points ) as total_consumed_by_user FROM user_current_points WHERE"


//$sql = "SELECT SUM( total_win_points )  FROM user_current_points WHERE username='111'";
$sql = "SELECT SUM(total_win_xp) FROM  user_current_xp WHERE username='$username'";
$result = mysqli_query($con, $sql);
$response = array();
while ($row = mysqli_fetch_array($result)) {
 //la columna cero ya que es la unica columna que recibe del servidor    
    array_push($response, array("total_win_xp" => $row[0],    
    )   );
}

$totalxp = $response['0']['total_win_xp'];
$totalFinal = $totalxp;
// $totalArray = array();
$totalArrayxp = array ('server_response_xp' =>$totalFinal );
        //  var_dump($totalArray);
        // die;
// $total = $response-$response2;


echo json_encode($totalArrayxp);

?>
